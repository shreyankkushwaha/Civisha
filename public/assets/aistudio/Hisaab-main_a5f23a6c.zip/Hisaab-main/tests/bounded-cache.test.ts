import { afterEach, expect, it, vi } from 'vitest';
import { BoundedCache } from '../src/lib/bounded-cache';
afterEach(() => vi.useRealTimers());
it('shares concurrent work and retains its completed result', async () => {
  const cache = new BoundedCache<string>(100, 2, 1000, (s) => s.length);
  let finish!: (value: string) => void;
  const load = vi.fn(() => new Promise<string>((resolve) => (finish = resolve)));
  const a = cache.get('same', load),
    b = cache.get('same', load);
  finish('record');
  expect(await a).toBe('record');
  expect(await b).toBe('record');
  expect(await cache.get('same', load)).toBe('record');
  expect(load).toHaveBeenCalledOnce();
});
it('expires results and retries failed loads', async () => {
  vi.useFakeTimers();
  const cache = new BoundedCache<string>(100, 2, 100, (s) => s.length);
  const load = vi.fn().mockRejectedValueOnce(new Error('down')).mockResolvedValue('ok');
  await expect(cache.get('a', load)).rejects.toThrow('down');
  expect(await cache.get('a', load)).toBe('ok');
  vi.advanceTimersByTime(101);
  expect(await cache.get('a', load)).toBe('ok');
  expect(load).toHaveBeenCalledTimes(3);
});
it('evicts by memory and entry limits without changing returned data', async () => {
  const cache = new BoundedCache<string>(6, 2, 1000, (s) => s.length);
  await cache.get('a', async () => 'aaa');
  await cache.get('b', async () => 'bbb');
  await cache.get('a', async () => 'wrong');
  await cache.get('c', async () => 'ccc');
  const reload = vi.fn(async () => 'bbb');
  expect(await cache.get('b', reload)).toBe('bbb');
  expect(reload).toHaveBeenCalledOnce();
  const big = vi.fn(async () => 'larger than cache');
  expect(await cache.get('big', big)).toBe('larger than cache');
  await cache.get('big', big);
  expect(big).toHaveBeenCalledTimes(2);
});
